# SVM Optimization Project - UCI Wine Dataset

This project focuses on optimizing Support Vector Machines (SVM) on the UCI Wine dataset. The implementation follows these steps:

## Project Overview

1. Load the Wine dataset from UCI Machine Learning Repository

   - Dataset contains 178 instances with 13 features and 3 classes
   - Each sample represents chemical measurements of different types of wine

2. Create 10 different training-testing splits

   - 70% training data and 30% testing data
   - Stratified sampling to maintain class distribution

3. Optimize SVM for each sample

   - Random search through parameter space with 100 iterations per sample
   - Parameters optimized: kernel type, C, gamma, degree (for polynomial kernel)
   - Parameters tracked: best accuracy and corresponding parameters

4. Analysis and Visualization
   - Comparative performance table of all samples
   - Convergence graph for the sample with maximum accuracy
   - Basic data analytics of the Wine dataset

## Requirements

- Python 3.6+
- Required packages:
  - numpy
  - pandas
  - scikit-learn
  - matplotlib
  - requests
  - tqdm

Install dependencies using:

```
pip install numpy pandas scikit-learn matplotlib requests tqdm
```

## How to Run

Simply execute the Python script:

```
python svm_optimization.py
```

The script will:

1. Download the Wine dataset from UCI
2. Create 10 different sample splits
3. Optimize SVM for each sample
4. Generate and save result table and plots
5. Print basic statistics about the dataset

## Expected Output

- Console output showing progress and results
- `svm_optimization_results.csv`: Table with best parameters for each sample
- `svm_convergence.png`: Convergence plot for the best performing sample
- `correlation_matrix.png`: Heatmap showing feature correlations

## Dataset Information

The Wine dataset contains the results of a chemical analysis of wines grown in a specific area of Italy. Three types of wine are represented in the 178 samples, with the analysis determining the quantities of 13 constituents found in each of the three types of wine.

### Attributes:

1. Alcohol
2. Malic acid
3. Ash
4. Alcalinity of ash
5. Magnesium
6. Total phenols
7. Flavanoids
8. Nonflavanoid phenols
9. Proanthocyanins
10. Color intensity
11. Hue
12. OD280/OD315 of diluted wines
13. Proline

### Classes:

- Class 1: 59 instances
- Class 2: 71 instances
- Class 3: 48 instances

## Implementation Details

The implementation uses random search to explore the parameter space efficiently. For each sample:

- Different kernels are tested (linear, polynomial, RBF, sigmoid)
- Parameters are randomly selected from appropriate distributions
- The best parameters and corresponding accuracy are recorded
- The convergence history is tracked for visualization

## Results Analysis

The results show how different train-test splits affect the optimization process and final accuracy. The convergence graph illustrates how the optimization algorithm improves over iterations.

## Future Improvements

Potential enhancements to this project:

- Implement grid search for more systematic parameter exploration
- Add cross-validation for more robust performance estimation
- Try different preprocessing techniques
- Implement ensemble methods combining multiple SVMs
